const { Router } = require('express');
const { check } = require('express-validator')

const { validarCampos } = require('../middlewares/validar-campos')

const { 
  getProductsListWithPage
   , getProductByID
   , insertProduct
   , updateProduct
  // , changePassword
  // , deleteUser
   } = require('../controllers/productsController');

   
const router = Router();

router.post('/getProductsListWithPage', getProductsListWithPage);

router.post('/getProductByID', [
  check('idProduct','Id obligatorio').not().isEmpty(),
  check('idProduct','Id debe ser numérico').isNumeric(),
  validarCampos
], getProductByID);

router.post('/insertProduct', [

  check('idUser','idUser obligatorio').not().isEmpty(),
  check('idUser','idUser debe ser numérico').isNumeric(),

  check('idFamily','idFamily obligatorio').not().isEmpty(),
  check('idFamily','idFamily debe ser numérico').isNumeric(),

  check('idGroup','idGroup obligatorio').not().isEmpty(),
  check('idGroup','idGroup debe ser numérico').isNumeric(),

  check('idQuality','idQuality obligatorio').not().isEmpty(),
  check('idQuality','idQuality debe ser numérico').isNumeric(),

  check('idOrigin','idOrigin obligatorio').not().isEmpty(),
  check('idOrigin','idOrigin debe ser numérico').isNumeric(),

  check('barCode','Código de barra obligatorio').not().isEmpty(),

  check('name','Nombre obligatorio').not().isEmpty(),

  check('cost','idOrigin debe ser numérico').isNumeric(),

  check('price','idOrigin debe ser numérico').isNumeric(),

  validarCampos
], insertProduct);

router.post('/updateProduct', [

  check('idProduct','idUser obligatorio').not().isEmpty(),
  check('idProduct','idUser debe ser numérico').isNumeric(),

  check('idUser','idUser obligatorio').not().isEmpty(),
  check('idUser','idUser debe ser numérico').isNumeric(),

  check('idFamily','idFamily obligatorio').not().isEmpty(),
  check('idFamily','idFamily debe ser numérico').isNumeric(),

  check('idGroup','idGroup obligatorio').not().isEmpty(),
  check('idGroup','idGroup debe ser numérico').isNumeric(),

  check('idQuality','idQuality obligatorio').not().isEmpty(),
  check('idQuality','idQuality debe ser numérico').isNumeric(),

  check('idOrigin','idOrigin obligatorio').not().isEmpty(),
  check('idOrigin','idOrigin debe ser numérico').isNumeric(),

  check('barCode','Código de barra obligatorio').not().isEmpty(),

  check('name','Nombre obligatorio').not().isEmpty(),

  check('cost','idOrigin debe ser numérico').isNumeric(),

  check('price','idOrigin debe ser numérico').isNumeric(),

  validarCampos
], updateProduct);

// router.post('/updateUser', [
//   check('name','Nombre obligatorio').not().isEmpty(),
//   check('userName','Usuario obligatorio').not().isEmpty(),

//   check('name','Nombre obligatorio').not().isEmpty(),

//   validarCampos
// ], updateUser);

// router.post('/changePassword', [
//   check('idUser','Id obligatorio').not().isEmpty(),
//   check('idUser','Id debe ser numérico').isNumeric(),

//   check('pwd','Usuario obligatorio').not().isEmpty(),

//   check('pwd2','Nombre obligatorio').not().isEmpty(),

//   validarCampos
// ], changePassword);

// router.post('/deleteUser', [
//   check('idUser','Id obligatorio').not().isEmpty(),
//   check('idUser','Id debe ser numérico').isNumeric(),
//   validarCampos
// ], deleteUser);

// router.post('/deletePaciente', [
//   check('idPaciente','Id obligatorio').not().isEmpty(),
//   check('idPaciente','Id debe ser numérico').isNumeric(),
//   validarCampos
// ], deletePaciente);

module.exports = router;
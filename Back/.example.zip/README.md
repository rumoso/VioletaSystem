#WebServer + RestServer

Base para iniciar un nuevo proyecto basado en nodejs para creación de servicios rest

Recuerda que se debe ejecutar ```npm install``` para reconstruir los módulos de node


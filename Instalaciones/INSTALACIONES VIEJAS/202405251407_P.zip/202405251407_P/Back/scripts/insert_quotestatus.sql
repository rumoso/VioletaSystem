INSERT INTO `artesgraficas`.`quotestatus` (`idQuoteStatus`, `name`, `description`, `active`) VALUES ('1', 'BORRADOR', 'BORRADOR', '1');
INSERT INTO `artesgraficas`.`quotestatus` (`idQuoteStatus`, `name`, `description`, `active`) VALUES ('2', 'PENDIENTE', 'PENDIENTE', '1');
INSERT INTO `artesgraficas`.`quotestatus` (`idQuoteStatus`, `name`, `description`, `active`) VALUES ('3', 'APROBADO', 'APROBADO', '1');
INSERT INTO `artesgraficas`.`quotestatus` (`idQuoteStatus`, `name`, `description`, `active`) VALUES ('4', 'CANCELADO', 'CANCELADO', '1');

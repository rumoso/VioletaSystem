const { response } = require('express');
const bcryptjs = require('bcryptjs');

const { dbConnection } = require('../database/config');

const getUsersListWithPage = async(req, res = response) => {

    const idUserLogON = req.header('idUserLogON')

    const {
        search = '', limiter = 10, start = 0
    } = req.body;

    //console.log(req.body)

    try{

        var OSQL = await dbConnection.query(`call getUsersListWithPage('${ search }',${ start },${ limiter })`)

        if(OSQL.length == 0){

            res.json({
                status:0,
                message:"Ejecutado correctamente.",
                data:{
                count: 0,
                rows: null
                }
            });

        }
        else{

            const iRows = ( OSQL.length > 0 ? OSQL[0].iRows: 0 );
            
            res.json({
                status: 0,
                message: "Ejecutado correctamente.",
                data:{
                    count: iRows,
                    rows: OSQL
                }
            });
            
        }
        
    }catch(error){
      
        res.json({
            status: 2,
            message: "Sucedió un error inesperado",
            data: error.message
        });
    }
};

const getUserByID = async(req, res = response) => {

    const {
        idUser
    } = req.body;

    //console.log(req.body)

    try{
        
        var OSQL = await dbConnection.query(`call getUserByID(${ idUser })`)

        if(OSQL.length == 0){

            res.json({
                status: 0,
                message: "No se encontró el usuario.",
                data: null
            });

        }
        else{

            res.json({
                status: 0,
                message: "Ejecutado correctamente.",
                data: OSQL[0]
            });

        }
        
    }catch(error){
      
        res.json({
            status: 2,
            message: "Sucedió un error inesperado",
            data: error.message
        });
    }

};

const insertUser = async(req, res) => {
    
    const {
        name,
        userName,
        pwd = '',
        authorizationCode = '',
        comision = 0,
        destajo = 0,
        active,

        idUserLogON,
        idSucursalLogON
        
    } = req.body;

    //console.log(req.body)

    try{

        //encript pwd
        const salt = bcryptjs.genSaltSync();
        const pwdEncrypt = bcryptjs.hashSync( pwd, salt);

        var OSQL = await dbConnection.query(`call insertUser(
        '${ name }'
        ,'${ userName }'
        ,'${ pwdEncrypt }'
        , '${ authorizationCode }'
        , '${ comision }'
        , '${ destajo }'
        , ${ active }

        , ${ idUserLogON }
        )`)

        res.json({
            status: OSQL[0].out_id > 0 ? 0 : 1,
            message: OSQL[0].message,
            insertID: OSQL[0].out_id
        });

    }catch(error){

        res.json({
            status: 2,
            message: "Sucedió un error inesperado",
            data: error.message
        });

    }
}

const updateUser = async(req, res) => {
   
    const {
        idUser,
        name,
        userName,
        pwd = '',
        authorizationCode = '',
        comision = 0,
        destajo = 0,
        active
    } = req.body;

    //console.log(req.body)

    try{

        var OSQL = await dbConnection.query(`call updateUser(
        ${ idUser }
        ,'${ name }'
        ,'${ userName }'
        ,'${ authorizationCode }'
        ,'${ comision }'
        , '${ destajo }'
        , ${ active }
        )`)

        //var ODeleteSync_up = await dbConnection.query(`call deleteSync_up( 'Users', ${ idUser } )`);

        res.json({
            status: OSQL[0].out_id > 0 ? 0 : 1,
            message: OSQL[0].message
        });

    }catch(error){

        res.json({
            status: 2,
            message: "Sucedió un error inesperado",
            data: error
        });

    }
}

const changePassword = async(req, res) => {

    const {
        idUser,
        pwd = '',
        pwd2 = ''
    } = req.body;

    //console.log(req.body)

    try{

        if(pwd == pwd2){

            //encript pwd
            const salt = bcryptjs.genSaltSync();
            const pwdEncrypt = bcryptjs.hashSync( pwd, salt);

            var OSQL = await dbConnection.query(`call updatePWD(
            ${idUser}
            ,'${pwdEncrypt}'
            )`)

            //var ODeleteSync_up = await dbConnection.query(`call deleteSync_up( 'Users', ${ idUser } )`);

            res.json({
                status: 0,
                message: "Contraseña actualizada con éxito.",
                insertID: OSQL[0].out_id
            });

        }else{

            res.json({
            status: 1,
            message: "Las contraseñas no coinciden",
            });

        }

    }catch(error){

        res.json({
            status: 2,
            message: "Sucedió un error inesperado",
            data: error.message
        });

    }
}

const disabledUser = async(req, res) => {
   
    const {
        idUser
    } = req.body;

    //console.log(req.body)

    try{

        var OSQL = await dbConnection.query(`call disabledUser(
        ${ idUser }
        )`)

        var ODeleteSync_up = await dbConnection.query(`call deleteSync_up( 'Users', ${ idUser } )`);

        res.json({
            status:0,
            message:"Usuario deshabilitado con éxito.",
            insertID: OSQL[0].out_id
        });

    }catch(error){

        res.json({
        status:2,
        message: "Sucedió un error inesperado",
        data: error.message
        });

    }
}

const cbxGetSellersCombo = async(req, res = response) => {

    const {
        idUser,
        search = ''
    } = req.body;

    //console.log(req.body)

    try{

        var OSQL = await dbConnection.query(`call cbxGetSellersCombo( ${ idUser },'${ search }' )`)

        if(OSQL.length == 0){

            res.json({
                status: 3,
                message: "No se encontró información.",
                data: null
            });

        }
        else{

            res.json({
                status:  0,
                message:"Ejecutado correctamente.",
                data: OSQL
            });

        }

    }catch(error){

        res.json({
            status: 2,
            message: "Sucedió un error inesperado",
            data: error.message
        });

    }

};

const cbxGetTecnicosCombo = async(req, res = response) => {

    const {
        search = ''
    } = req.body;

    try{

        const OSQL = await dbConnection.query(`
            SELECT DISTINCT
                u.idUser as id,
                u.name as nombre,
                u.userName
            FROM users u
            INNER JOIN rolesconfig rc ON u.idUser = rc.idUser
            INNER JOIN roles r ON rc.idRol = r.idRol
            WHERE r.name = 'Técnico'
            AND (u.name LIKE :search OR u.userName LIKE :search)
            ORDER BY u.name ASC
        `, {
            replacements: { search: `%${search}%` },
            type: dbConnection.QueryTypes.SELECT
        });

        if(OSQL.length == 0){

            res.json({
                status: 3,
                message: "No se encontró información.",
                data: null
            });

        }
        else{

            res.json({
                status:  0,
                message:"Ejecutado correctamente.",
                data: OSQL
            });

        }

    }catch(error){

        res.json({
            status: 2,
            message: "Sucedió un error inesperado",
            data: error.message
        });

    }

};

const updateAuthorizationCode = async(req, res) => {

    const {
        idUser,
        authorizationCode
    } = req.body;

    //console.log(req.body)

    try{

        var OSQL = await dbConnection.query(`call updateAuthorizationCode(
        ${ idUser }
        ,'${ authorizationCode }'
        )`)

        //var ODeleteSync_up = await dbConnection.query(`call deleteSync_up( 'Users', ${ idUser } )`);

        res.json({
            status: OSQL[0].out_id > 0 ? 0 : 1,
            message: OSQL[0].message
        });

    }catch(error){

        res.json({
            status: 2,
            message: "Sucedió un error inesperado",
            data: error.message
        });

    }
}

const cbxGetAllUsersCombo = async(req, res = response) => {

    const { search = '' } = req.body;

    try {
        const OSQL = await dbConnection.query(`
            SELECT
                u.idUser  AS id,
                u.name    AS nombre,
                u.userName
            FROM users u
            WHERE u.active = 1
              AND (u.name LIKE :search OR u.userName LIKE :search)
            ORDER BY u.name ASC
            LIMIT 50
        `, {
            replacements: { search: `%${search}%` },
            type: dbConnection.QueryTypes.SELECT
        });

        if (OSQL.length === 0) {
            res.json({ status: 3, message: 'No se encontró información.', data: [] });
        } else {
            res.json({ status: 0, message: 'Ejecutado correctamente.', data: OSQL });
        }

    } catch (error) {
        res.json({ status: 2, message: 'Sucedió un error inesperado', data: error.message });
    }
};

module.exports = {
    getUsersListWithPage
    , getUserByID
    , insertUser
    , updateUser
    , changePassword
    , disabledUser
    , cbxGetSellersCombo
    , cbxGetTecnicosCombo
    , updateAuthorizationCode
    , cbxGetAllUsersCombo
}